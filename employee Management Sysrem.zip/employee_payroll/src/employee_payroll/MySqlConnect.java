/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee_payroll;
import java.sql.*;
import javax.swing.*;
/**
 *
 * @author SAJEEB BHAI
 */
public class MySqlConnect {
    Connection conn=null;
    public static Connection ConnectDB(){
    try{
     Class.forName("com.mysql.jdbc.Driver");
     Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/employee_payroll","root","");
     JOptionPane.showMessageDialog(null, "Connected to database");
     return conn;
    }
catch(Exception e){
    JOptionPane.showMessageDialog(null, e);
    return null;
}
}
    
}
